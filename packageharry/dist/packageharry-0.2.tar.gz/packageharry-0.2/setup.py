import packageharry
from setuptools import setup
setup(name="packageharry",
version="0.2",
description="this is cood with harry package",
long_description="this is a very very long description",
auther="harry",
packages=["packageharry"],
install_requires=[])
