class accha:
    def __init__(self):
        print("constructer bangaya")

    def achhafunc(self,number):
        print("This is a function")
        return number


# to run this == python setup.py sdist bdist_wheel after this cd .\dist\ after this ls after this pip install your packeg name which in whl
# realise this dont open terminal in this file in which you enter the information of the your module

